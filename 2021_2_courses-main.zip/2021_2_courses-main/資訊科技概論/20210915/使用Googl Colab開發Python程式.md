# 課程宗旨
```
使用Google Colab平台學習python程式設計
```
