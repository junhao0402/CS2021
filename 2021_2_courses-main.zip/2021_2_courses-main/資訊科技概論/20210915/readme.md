# 實作主題
```
1.DOWNLOAD(下載)並安裝(install) virtualbox

2.下載linux 的ova

3.匯入 linux

4.申請github
  將GITHUB PO在網路大學

5.使用GOOGLE gmail登入

6.使用Googl Colab開發Python
```

# 1.DOWNLOAD(下載)並安裝(install) virtualbox

- [virtualbox下載區](https://www.virtualbox.org/wiki/Downloads)

![下載紅色的兩個檔案](./20210915BOX.png)


# 2.下載linux 的ova


# 4.申請github

- [微軟大砸75億美元買下GitHub 2018.6](https://www.ithome.com.tw/news/123625)

![申請github帳號](./20210915GITHUB.png)
