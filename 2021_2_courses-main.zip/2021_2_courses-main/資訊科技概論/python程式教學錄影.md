# python程式教學錄影
| 章節 | YOUTUBE網址|
|-----|--------|
| ch0_使用GoogleColab開發python程式 | https://youtu.be/E2VOQXlbQog  |
| ch1_基本輸出入 | https://youtu.be/EvhChZzoDes  |
| ch2_1_數值型資料型態及其運算 |  https://youtu.be/93vcPXSfzyk |
| ch2_2_字串(string)及其運算 |   |
| ch2_3_列表(list)資料及其運算 |   |
| ch2_4_字典(dict)資料及其運算 |   |
| ch3_決策與選擇結構(SELECTION /DECISION)字典(dict)資料及其運算 |   |
| ch4_廻圈loop| |
| ch5_函數| |
| ch6_初階模組化程式設計| |


## 
| | |
| | |
