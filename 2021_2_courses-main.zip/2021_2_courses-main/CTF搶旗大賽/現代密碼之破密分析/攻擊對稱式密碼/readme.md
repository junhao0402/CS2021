#
```
區塊加密攻擊⽅法 
cut-and-paste attack on ECB
POODLE attack(Padding Oracle Attack)
BEAST(Browser Exploit Against SSL/TLS)
………

```
https://oalieno.github.io/old/security/crypto/symmetric/padding-oracle/
