# Linux 雲端技術
```
虛擬化技術 KVM
容器化技術 docker
大型雲端技術 Kubernetes
```
