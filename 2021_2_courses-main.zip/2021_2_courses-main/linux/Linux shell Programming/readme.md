
# Linux shell Programming參考書籍
- [Bash Cookbook (簡體中文版)](https://www.tenlong.com.tw/products/9787115527011) [[GITHUB]](https://github.com/PacktPublishing/Bash-Cookbook)

```
第1章Bash速成
第2章文本與文件處理
第3章精通文件系統
第4章像【守護進程 Daemon】一樣的腳本Making a Script Behave Like a Daemon
第5章系統管理腳本
第6章高級用戶專用腳本
第7章Bash致勝之道
第8章高級腳本技術
```

- [Bash 資安管理手冊 (Cybersecurity Ops with bash)](https://www.tenlong.com.tw/products/9789865023232)  [[GITHUB]](https://github.com/cybersecurityops/cyber-ops-with-bash)
- [Linux Shell 程式設計與管理實務, 3/e 臥龍小三  博碩文化 2017-07-09](https://www.tenlong.com.tw/products/9789864342266)
- [Linux Shell 腳本攻略, 3/e Linux Shell脚本攻略 第3版 [美]克裡夫·弗林特 2018-03-01](https://www.tenlong.com.tw/products/9787115477385)
- [系統管理員懶人包｜Shell Script 自動化指令集 (Wicked Cool Shell Scripts) Dave Taylor, Brandon Perry 著、江湖海 譯 碁峰資訊 2017-04-10](https://www.tenlong.com.tw/products/9789864763672)
