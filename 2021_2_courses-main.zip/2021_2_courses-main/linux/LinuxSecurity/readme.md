# 


### [Linux 伺服器安全防護 (Building Secure Servers with Linux) Michael D. Bauer(2002)已絕版的好書](https://www.oreilly.com/library/view/building-secure-servers/0596002173/) [[中文版]](https://www.tenlong.com.tw/products/9789867794185)

### [Linux 網路安全技術與實現, 2/e 陳勇勳 悅知文化已絕版](https://www.tenlong.com.tw/products/9789866072147)

### [MIS 的安全防禦：Linux 系統與網路安全|酆士昌 著|博碩文化(2017)](https://www.tenlong.com.tw/products/9789864341863)

### [LINUX FIREWALLS 4/e (中文版) (Linux Firewalls: Enhancing Security with nftables and Beyond, 4/e)Steve Suehring 王文燁|博碩文化](https://www.tenlong.com.tw/products/9789864344239)
```
▶針對執行iptables或nftables的Linux防火牆，進行安裝、設定以及更新
▶遷移到nftables，或者使用新的iptables增強機制
▶管理複雜的多重防火牆設定
▶建立、除錯和最佳化防火牆規則
▶使用Samhain和其他工具來保護文件系統的完整性，以及監控網路和檢測入侵
▶增強系統以防禦埠掃描和其他攻擊
▶使用chkrootkit檢測惡意軟體rootkit和後門等漏洞
```

### [UNIX\Linux 網絡日誌分析與流量監控 UNIX/Linux网络日志分析与流量监控 李晨光 機械工業(2015)](https://www.tenlong.com.tw/products/9787111479611)

### [Linux 系統安全：縱深防禦、安全掃描與入侵檢測 胥峰　著 機械工業(2019)](https://www.tenlong.com.tw/products/9787111632184)
