# python

- https://discord.gg/YKnutrsZ

- 1. find Google colab
- 2. log in with Google account

## python1

```python
print("" Hello My friends!")
```

## python2
```python
import pandas as pd
print("pandas version: %s" % pd.__version__)
```

## Python3: basic input and output
```
input() ==> read data from keyboard

print() ==> show your result to Monitor
```
```python

x = input('Show me your money')
print("Thank for your money " + x)
```

```
You want to know the data type of x ==> Use type() function
type(x)
```
## Python4 
```
write a program
read some money from keyboard  say x <--- money
add 12345 dollars to x  ==> y = x + 12345  
```
## python5
```python
a,b = eval(input("PLease input two digits:"))
a,b
```
